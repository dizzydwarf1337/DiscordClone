
export default interface ApiResponseModel {
    success: boolean;
    data: any;
    message: string
}