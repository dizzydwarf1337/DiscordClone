

export default interface RegisterModel {
    username: string,
    email: string,
    password: string,
}